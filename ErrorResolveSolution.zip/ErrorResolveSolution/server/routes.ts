import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertUserSchema, loginSchema, messageSchema } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";
import express from "express";
import path from "path";

const MemoryStoreSession = MemoryStore(session);

declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

interface AuthenticatedWebSocket extends WebSocket {
  userId?: number;
  codename?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve attached assets with proper content type
  app.use('/attached_assets', express.static(path.resolve(process.cwd(), 'attached_assets'), {
    setHeaders: (res, path) => {
      if (path.endsWith('.png')) {
        res.setHeader('Content-Type', 'image/png');
      } else if (path.endsWith('.jpg') || path.endsWith('.jpeg')) {
        res.setHeader('Content-Type', 'image/jpeg');
      } else if (path.endsWith('.gif')) {
        res.setHeader('Content-Type', 'image/gif');
      } else if (path.endsWith('.svg')) {
        res.setHeader('Content-Type', 'image/svg+xml');
      }
    }
  }));

  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'cyberhub-secret-key',
    resave: false,
    saveUninitialized: false,
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: {
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Auth middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Register endpoint
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser(userData);
      req.session.userId = user.id;
      
      res.json({ 
        success: true, 
        user: { 
          id: user.id, 
          username: user.username, 
          codename: user.codename 
        } 
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid registration data" });
    }
  });

  // Login endpoint
  app.post("/api/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const user = await storage.verifyUser(loginData.username, loginData.password);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      
      res.json({ 
        success: true, 
        user: { 
          id: user.id, 
          username: user.username, 
          codename: user.codename 
        } 
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid login data" });
    }
  });

  // Logout endpoint
  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.json({ success: true });
    });
  });

  // Get current user
  app.get("/api/user", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          codename: user.codename 
        } 
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get messages
  app.get("/api/messages", requireAuth, async (req, res) => {
    try {
      const messages = await storage.getMessages();
      const messagesWithUsers = await Promise.all(
        messages.map(async (message) => {
          const user = await storage.getUser(message.userId);
          return {
            id: message.id,
            content: message.content,
            timestamp: message.timestamp,
            codename: user?.codename || 'Unknown'
          };
        })
      );
      
      res.json({ messages: messagesWithUsers });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Reset storage (untuk development)
  app.post("/api/reset", (req, res) => {
    (storage as any).reset();
    res.json({ success: true, message: "Storage berhasil direset" });
  });

  const httpServer = createServer(app);
  
  // WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const connectedClients = new Map<number, AuthenticatedWebSocket>();
  
  wss.on('connection', (ws: AuthenticatedWebSocket, req) => {
    console.log('New WebSocket connection');
    
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'auth') {
          // Handle authentication
          const user = await storage.getUser(message.userId);
          if (user) {
            ws.userId = user.id;
            ws.codename = user.codename;
            connectedClients.set(user.id, ws);
            
            // Broadcast user joined
            broadcastToAll({
              type: 'user-joined',
              codename: user.codename,
              timestamp: new Date()
            });
            
            // Send current user count
            broadcastToAll({
              type: 'user-count',
              count: connectedClients.size
            });
          }
        } else if (message.type === 'chat-message' && ws.userId) {
          // Handle chat message
          const messageData = messageSchema.parse({ content: message.content });
          
          const savedMessage = await storage.createMessage(ws.userId, messageData.content);
          
          // Broadcast message to all clients
          broadcastToAll({
            type: 'message',
            id: savedMessage.id,
            content: savedMessage.content,
            codename: ws.codename,
            timestamp: savedMessage.timestamp
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      if (ws.userId) {
        connectedClients.delete(ws.userId);
        
        // Broadcast user left
        if (ws.codename) {
          broadcastToAll({
            type: 'user-left',
            codename: ws.codename,
            timestamp: new Date()
          });
        }
        
        // Send updated user count
        broadcastToAll({
          type: 'user-count',
          count: connectedClients.size
        });
      }
    });
  });
  
  function broadcastToAll(message: any) {
    const messageString = JSON.stringify(message);
    connectedClients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageString);
      }
    });
  }

  return httpServer;
}
