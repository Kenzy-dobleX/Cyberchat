const adjectives = [
  'Dark', 'Silent', 'Cyber', 'Shadow', 'Ghost', 'Hidden', 'Anon', 'Deadly',
  'Neon', 'Digital', 'Quantum', 'Binary', 'Matrix', 'Phantom', 'Void', 'Steel'
];

const nouns = [
  'Wolf', 'Fox', 'Raven', 'Hunter', 'Phantom', 'Tiger', 'Falcon', 'Blade',
  'Viper', 'Dragon', 'Hawk', 'Panther', 'Cobra', 'Phoenix', 'Reaper', 'Wraith'
];

export function generateCodename(): string {
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const number = Math.floor(Math.random() * 900 + 100);
  return `${adj}${noun}${number}`;
}
