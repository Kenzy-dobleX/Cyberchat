import { users, messages, type User, type InsertUser, type Message } from "@shared/schema";
import { generateCodename } from "./utils/codename";
import bcrypt from "bcrypt";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyUser(username: string, password: string): Promise<User | null>;
  getMessages(limit?: number): Promise<Message[]>;
  createMessage(userId: number, content: string): Promise<Message>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private currentUserId: number;
  private currentMessageId: number;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const codename = generateCodename();
    
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      password: hashedPassword,
      codename,
      createdAt: new Date(),
    };
    
    this.users.set(id, user);
    return user;
  }

  async verifyUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getMessages(limit: number = 50): Promise<Message[]> {
    const allMessages = Array.from(this.messages.values())
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-limit);
    
    return allMessages;
  }

  async createMessage(userId: number, content: string): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      id,
      userId,
      content,
      timestamp: new Date(),
    };
    
    this.messages.set(id, message);
    return message;
  }

  // Method untuk reset storage (untuk testing)
  reset(): void {
    this.users.clear();
    this.messages.clear();
    this.currentUserId = 1;
    this.currentMessageId = 1;
  }
}

export const storage = new MemStorage();
