import { useState, useEffect, useRef } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { logout } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import type { AuthUser } from "@/lib/auth";
import { Send, MoreVertical, Phone, VideoIcon, Search } from "lucide-react";

interface ChatPageProps {
  user: AuthUser;
  onLogout: () => void;
}

export function ChatPage({ user, onLogout }: ChatPageProps) {
  const [messageInput, setMessageInput] = useState("");
  const { messages, systemMessages, connectedUsers, connected, sendMessage } = useWebSocket(user);
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, systemMessages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim()) {
      sendMessage(messageInput);
      setMessageInput("");
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      onLogout();
      toast({
        title: "Disconnected",
        description: "Secure session terminated",
      });
    } catch (error) {
      toast({
        title: "Logout Failed",
        description: "Error terminating session",
        variant: "destructive",
      });
    }
  };

  // Combine and sort messages
  const allMessages = [
    ...messages.map(msg => ({ ...msg, messageType: 'message' as const })),
    ...systemMessages.map(msg => ({ ...msg, messageType: 'system' as const }))
  ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  return (
    <div className="min-h-screen bg-whatsapp-bg flex flex-col">
      {/* WhatsApp Header */}
      <div className="whatsapp-header p-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 flex items-center justify-center">
            <img 
              src="/attached_assets/dkz_team_resized_300x300_1751628401633.png"
              alt="DKZ Team Logo"
              className="w-10 h-10 object-contain rounded-full"
            />
          </div>
          <div>
            <h1 className="text-blue-900 font-semibold text-lg">DKZ Team Chat</h1>
            <p className="text-blue-700 text-sm">
              {connectedUsers} peserta • {connected ? 'online' : 'offline'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-whatsapp-green-dark p-2"
          >
            <VideoIcon className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-whatsapp-green-dark p-2"
          >
            <Phone className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-whatsapp-green-dark p-2"
          >
            <Search className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-whatsapp-green-dark p-2"
            onClick={handleLogout}
          >
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Chat Messages Area */}
      <div className="flex-1 whatsapp-chat-bg p-4 overflow-hidden">
        <ScrollArea className="h-full">
          <div className="space-y-2 pb-4">
            {allMessages.map((msg, index) => (
              <div key={index} className="flex flex-col">
                {msg.messageType === 'message' ? (
                  <div className={`flex ${msg.codename === user.codename ? 'justify-end' : 'justify-start'}`}>
                    <div className={`whatsapp-chat-bubble ${
                      msg.codename === user.codename 
                        ? 'whatsapp-msg-own' 
                        : 'whatsapp-msg-other'
                    }`}>
                      {msg.codename !== user.codename && (
                        <p className="text-blue-600 font-semibold text-sm mb-1">
                          {msg.codename}
                        </p>
                      )}
                      <p className="text-blue-900">{(msg as any).content}</p>
                      <p className="whatsapp-time text-right mt-1">
                        {new Date(msg.timestamp).toLocaleTimeString('id-ID', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex justify-center mb-2">
                    <div className="whatsapp-msg-system px-3 py-1">
                      <p className="text-blue-700 text-sm">
                        {msg.codename} {(msg as any).type === 'join' ? 'bergabung' : 'keluar'}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>

      {/* Message Input */}
      <div className="bg-whatsapp-bg border-t border-gray-700 p-4">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <Input
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            placeholder="Ketik pesan..."
            className="whatsapp-input flex-1 border-none focus:ring-0 focus:border-none"
          />
          <Button
            type="submit"
            disabled={!connected || !messageInput.trim()}
            className="whatsapp-send-btn"
            size="sm"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
