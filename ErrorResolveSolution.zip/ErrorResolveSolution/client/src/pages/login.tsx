import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, insertUserSchema } from "@shared/schema";
import { login, register } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

import type { AuthUser } from "@/lib/auth";

interface LoginPageProps {
  onLogin: (user: AuthUser) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const handleLogin = async (data: any) => {
    setLoading(true);
    try {
      const user = await login(data);
      onLogin(user);
      toast({
        title: "Access Granted",
        description: `Welcome back, ${user.codename}`,
      });
    } catch (error) {
      toast({
        title: "Access Denied",
        description: "Invalid credentials",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (data: any) => {
    setLoading(true);
    try {
      const user = await register(data);
      onLogin(user);
      toast({
        title: "Identity Created",
        description: `Welcome to the Hub, ${user.codename}`,
      });
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: "Username already exists or invalid data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-whatsapp-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* DKZ Team Header */}
        <div className="text-center mb-8">
          <div className="w-32 h-32 mx-auto mb-4 flex items-center justify-center">
            <img 
              src="/attached_assets/dkz_team_resized_300x300_1751628401633.png"
              alt="DKZ Team Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-blue-900 text-2xl font-semibold mb-2">DKZ Team Chat</h1>
          <p className="text-blue-700 text-sm">Masuk atau daftar untuk bergabung</p>
          <div className="bg-whatsapp-green/20 border border-whatsapp-green/30 rounded-lg p-3 mt-4">
            <p className="text-whatsapp-green text-xs">
              💡 Tips: Gunakan username dan password sederhana seperti "test" dan "123"
            </p>
          </div>
        </div>

        {/* Login/Register Forms */}
        <Card className="bg-whatsapp-msg-bg border-gray-700 border">
          <CardHeader className="pb-4">
            <CardTitle className="text-center text-blue-900 text-lg">
              {isRegistering ? "Daftar Akun Baru" : "Masuk ke Akun"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isRegistering ? (
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-blue-800">Nama Pengguna</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Contoh: john123"
                            className="whatsapp-input"
                            autoComplete="username"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-blue-800">Password</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="text"
                            placeholder="Contoh: mypassword123"
                            className="whatsapp-input"
                            autoComplete="new-password"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-whatsapp-green hover:bg-whatsapp-green-dark text-white font-semibold py-3 rounded-lg"
                  >
                    {loading ? "Mendaftar..." : "Daftar"}
                  </Button>
                </form>
              </Form>
            ) : (
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-blue-800">Nama Pengguna</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Masukkan nama pengguna..."
                            className="whatsapp-input"
                            autoComplete="username"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-blue-800">Password</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="text"
                            placeholder="Masukkan password..."
                            className="whatsapp-input"
                            autoComplete="current-password"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-whatsapp-green hover:bg-whatsapp-green-dark text-white font-semibold py-3 rounded-lg"
                  >
                    {loading ? "Masuk..." : "Masuk"}
                  </Button>
                </form>
              </Form>
            )}
            
            <div className="text-center mt-4 space-y-2">
              <Button
                variant="ghost"
                onClick={() => setIsRegistering(!isRegistering)}
                className="text-whatsapp-green hover:text-whatsapp-green-dark"
              >
                {isRegistering ? "Sudah punya akun? Masuk" : "Belum punya akun? Daftar"}
              </Button>
              
              {isRegistering && (
                <div>
                  <Button
                    variant="ghost"
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/reset', { method: 'POST' });
                        if (response.ok) {
                          toast({
                            title: "Reset berhasil",
                            description: "Sekarang Anda bisa mendaftar dengan username apapun",
                          });
                        }
                      } catch (error) {
                        console.error('Reset error:', error);
                      }
                    }}
                    className="text-orange-400 hover:text-orange-300 text-sm"
                  >
                    🔄 Reset Data (jika registrasi gagal)
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-xs text-blue-600">
          DKZ Team Technical Tech - Chat Aman & Terpercaya
        </div>
      </div>
    </div>
  );
}
