import { useEffect, useRef } from "react";

export function MatrixBackground() {
  const canvasRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = canvasRef.current;
    if (!container) return;

    const characters = '0123456789ABCDEF';
    const drops: HTMLElement[] = [];
    
    for (let i = 0; i < 50; i++) {
      const drop = document.createElement('div');
      drop.style.position = 'absolute';
      drop.style.left = Math.random() * 100 + '%';
      drop.style.animationDuration = Math.random() * 3 + 2 + 's';
      drop.style.animationDelay = Math.random() * 2 + 's';
      drop.style.color = '#00FF00';
      drop.style.fontSize = '12px';
      drop.style.fontFamily = 'monospace';
      drop.style.animation = 'matrixFall 4s linear infinite';
      drop.textContent = characters[Math.floor(Math.random() * characters.length)];
      
      container.appendChild(drop);
      drops.push(drop);
    }

    return () => {
      drops.forEach(drop => drop.remove());
    };
  }, []);

  return <div ref={canvasRef} className="matrix-rain" />;
}
