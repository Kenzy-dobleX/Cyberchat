import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { LoginPage } from "@/pages/login";
import { ChatPage } from "@/pages/chat";
import type { AuthUser } from "@/lib/auth";

function AppContent() {
  const { user, setUser, loading } = useAuth();

  const handleLogin = (authUser: AuthUser) => {
    setUser(authUser);
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-matrix-green cyber-glow">
          <i className="fas fa-spinner fa-spin mr-2"></i>
          INITIALIZING SECURE CONNECTION...
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/chat">
        {user ? (
          <ChatPage user={user} onLogout={handleLogout} />
        ) : (
          <LoginPage onLogin={handleLogin} />
        )}
      </Route>
      <Route>
        {user ? (
          <ChatPage user={user} onLogout={handleLogout} />
        ) : (
          <LoginPage onLogin={handleLogin} />
        )}
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
