import { apiRequest } from "./queryClient";
import type { LoginData, InsertUser } from "@shared/schema";

export interface AuthUser {
  id: number;
  username: string;
  codename: string;
}

export async function login(credentials: LoginData): Promise<AuthUser> {
  const response = await apiRequest("POST", "/api/login", credentials);
  const data = await response.json();
  return data.user;
}

export async function register(userData: InsertUser): Promise<AuthUser> {
  const response = await apiRequest("POST", "/api/register", userData);
  const data = await response.json();
  return data.user;
}

export async function logout(): Promise<void> {
  await apiRequest("POST", "/api/logout");
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const response = await apiRequest("GET", "/api/user");
    const data = await response.json();
    return data.user;
  } catch (error) {
    return null;
  }
}
