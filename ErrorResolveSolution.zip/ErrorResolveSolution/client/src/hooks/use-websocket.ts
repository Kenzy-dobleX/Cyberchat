import { useState, useEffect, useRef } from "react";
import type { AuthUser } from "@/lib/auth";

export interface ChatMessage {
  id: number;
  content: string;
  codename: string;
  timestamp: Date;
}

export interface SystemMessage {
  type: 'join' | 'leave';
  codename: string;
  timestamp: Date;
}

export function useWebSocket(user: AuthUser | null) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [systemMessages, setSystemMessages] = useState<SystemMessage[]>([]);
  const [connectedUsers, setConnectedUsers] = useState(0);
  const [connected, setConnected] = useState(false);
  const ws = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!user) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);

    ws.current.onopen = () => {
      setConnected(true);
      // Authenticate with the server
      ws.current?.send(JSON.stringify({
        type: 'auth',
        userId: user.id
      }));
    };

    ws.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'message':
          setMessages(prev => [...prev, {
            id: data.id,
            content: data.content,
            codename: data.codename,
            timestamp: new Date(data.timestamp)
          }]);
          break;
        
        case 'user-joined':
          setSystemMessages(prev => [...prev, {
            type: 'join',
            codename: data.codename,
            timestamp: new Date(data.timestamp)
          }]);
          break;
        
        case 'user-left':
          setSystemMessages(prev => [...prev, {
            type: 'leave',
            codename: data.codename,
            timestamp: new Date(data.timestamp)
          }]);
          break;
        
        case 'user-count':
          setConnectedUsers(data.count);
          break;
      }
    };

    ws.current.onclose = () => {
      setConnected(false);
    };

    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, [user]);

  const sendMessage = (content: string) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({
        type: 'chat-message',
        content
      }));
    }
  };

  return {
    messages,
    systemMessages,
    connectedUsers,
    connected,
    sendMessage
  };
}
