# CyberHub Chat Application

## Overview

This is a full-stack chat application built with a modern technology stack featuring a React frontend and Express backend. The application implements a cyberpunk-themed interface with real-time messaging capabilities, user authentication, and dynamic codename generation for users.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **Styling**: Tailwind CSS with custom cyberpunk theme
- **UI Components**: Radix UI components with shadcn/ui styling
- **State Management**: React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Real-time Communication**: WebSocket implementation for chat functionality
- **Session Management**: Express sessions with memory store
- **Authentication**: BCrypt for password hashing
- **Database**: PostgreSQL with Drizzle ORM (configured but may use alternative storage)

## Key Components

### Authentication System
- User registration and login functionality
- Session-based authentication with secure cookie management
- Password hashing using BCrypt
- Automatic codename generation for users

### Real-time Chat System
- WebSocket-based real-time messaging
- System messages for user join/leave events
- Message history persistence
- Connected user count tracking

### Database Schema
- **Users Table**: ID, username, password, codename, creation timestamp
- **Messages Table**: ID, user ID, content, timestamp
- Uses Drizzle ORM with PostgreSQL dialect
- Zod schema validation for type safety

### UI/UX Design
- Cyberpunk aesthetic with matrix-green color scheme
- Responsive design with mobile considerations
- Custom CSS animations and effects
- Terminal-style interface elements

## Data Flow

1. **User Registration/Login**:
   - Frontend form submission → Backend validation → Database storage → Session creation
   - Automatic codename generation during registration

2. **Real-time Messaging**:
   - User sends message → WebSocket transmission → Server broadcasts to all connected clients
   - Message persistence to database for history

3. **Authentication Flow**:
   - Session-based authentication with server-side validation
   - Protected routes requiring authentication
   - Automatic logout on session expiry

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, React DOM, React Query)
- Radix UI components for accessible UI primitives
- Tailwind CSS for styling
- Wouter for routing
- React Hook Form and Zod for form handling

### Backend Dependencies
- Express.js for server framework
- WebSocket (ws) for real-time communication
- Drizzle ORM for database operations
- BCrypt for password security
- Express sessions for authentication

### Development Dependencies
- Vite for development server and building
- TypeScript for type safety
- ESBuild for backend bundling
- Replit-specific plugins for development environment

## Deployment Strategy

### Development Mode
- Vite dev server for frontend hot reloading
- Node.js with tsx for backend development
- Concurrent frontend and backend development

### Production Build
- Frontend: Vite build generating static assets
- Backend: ESBuild bundle for Node.js execution
- Single Node.js process serving both API and static files

### Environment Configuration
- Database URL configuration via environment variables
- Session secret management
- Development vs production environment detection

## Changelog

```
Changelog:
- July 04, 2025. Initial setup
- July 04, 2025. Changed interface to WhatsApp group style with green theme
- July 04, 2025. Fixed registration issues and simplified form validation
- July 04, 2025. Made password fields visible (not hidden) per user request
- July 04, 2025. Added reset functionality for easier testing
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```